Set of ML tools for small projects

## Installation
`pip install ML-tools`


## Usage

### Post message to Slack
`SlackNotifier(TOKEN).message("testing baby")`


### Post error to Slack

